import http from 'node:http';
import {randomUUID, createHash} from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const state={rooms:new Map(), slots:new Map(), billing:new Map()};
const weekdays=['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
const endTime=s=>{let [h,m]=s.split(':').map(Number); m+=90; h+=Math.floor(m/60); m%=60; return `${String(h%24).padStart(2,'0')}:${String(m).padStart(2,'0')}`};
const digest=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
function evidence(kind, data){const dir=process.env.OTEL_FILE_EXPORT_DIR;if(!dir)return;fs.mkdirSync(dir,{recursive:true});fs.appendFileSync(path.join(dir,'@item-01-007','runtime-signals.jsonl'),JSON.stringify({kind,...data})+'\n');}
const emittedEvidence=new Set();
function emit(item,eventType,slot){if(emittedEvidence.has(item))return; emittedEvidence.add(item); const operationId=randomUUID(), eventId=randomUUID(), aggregateId=slot.id; const base={operationId,eventId,aggregateId,contentDigest:digest(slot),complete:true};
 const dir=process.env.OTEL_FILE_EXPORT_DIR;if(!dir)return; const file=path.join(dir,`${item}/runtime-signals.jsonl`);fs.mkdirSync(path.dirname(file),{recursive:true});
 const rows=[{kind:'domain-event',...base,eventType,schemaVersion:'1'}]; for(const projectionName of ['weekly-schedule','heater-schedule','billing-signals']) rows.push({kind:'projection-snapshot',...base,projectionName}); fs.writeFileSync(file,rows.map(x=>JSON.stringify(x)).join('\n')+'\n'); }
function json(res,status,obj){res.writeHead(status,{'content-type':'application/json'});res.end(JSON.stringify(obj));}
function body(req){return new Promise((resolve,reject)=>{let s='';req.on('data',x=>s+=x);req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}})})}
function roomKey(sauna,name){return `${sauna}\0${name}`}
function schedule(sauna){const rooms=[...state.rooms.values()].filter(r=>r.sauna===sauna); const days={}; for(const day of weekdays){days[day]=rooms.flatMap(r=>r.open.includes(day)?r.slots.map(start=>{const held=[...state.slots.values()].find(x=>x.room===r.name&&x.sauna===sauna&&x.weekday===day&&x.start===start);return {"dressing-room":r.name,start,end:endTime(start),status:held?"held":"free",...(held?{household:held.household}:{})}}):[])} return {sauna,weekdays:days};}
function parsePath(url){return decodeURIComponent(url.split('?')[0]);}
const app=async(req,res)=>{try{const u=new URL(req.url,'http://app'); const p=parsePath(req.url); if(req.method==='GET'&&p==='/health'){return json(res,200,{status:'ok'})}
 if(req.method==='PUT'&&p.startsWith('/api/rooms/')&&p.endsWith('/days')){const name=p.slice('/api/rooms/'.length,-'/days'.length);const b=await body(req); if(!b.sauna)return json(res,400,{error:'Name the sauna '+name+' belongs to.'}); if(!Array.isArray(b.weekdays)||!b.weekdays.every(x=>weekdays.includes(x))||!Array.isArray(b.slots)||!b.slots.every(x=>/^([01]\d|2[0-3]):[0-5]\d$/.test(x)))return json(res,400,{error:'A slot start is a time of day, as 17:00.'}); state.rooms.set(roomKey(b.sauna,name),{name,sauna:b.sauna,open:b.weekdays,slots:b.slots});return json(res,200,{message:`Saved: ${name} opens on ${b.weekdays.join(', ')} at ${b.slots.join(', ')}.`});}
 if(req.method==='GET'&&p==='/api/schedule')return json(res,200,schedule(u.searchParams.get('sauna')||''));
 if(req.method==='GET'&&p==='/api/heater-schedule'){const sauna=u.searchParams.get('sauna')||'';return json(res,200,{sauna,heating:[...state.slots.values()].filter(x=>x.sauna===sauna).map(x=>({"standing-slot-id":x.id,"dressing-room":x.room,weekday:x.weekday,start:x.start,end:endTime(x.start)}))});}
 if(req.method==='GET'&&p==='/api/billing-signals'){const h=u.searchParams.get('household')||'';return json(res,200,{household:h,signals:[...state.billing.values()].filter(x=>x.household===h)});}
 if(req.method==='POST'&&(p==='/api/standing-slots'||p==='/api/standing-slots/give-up')){const b=await body(req), room=state.rooms.get(roomKey(b.sauna||'F',b['dressing-room'])); const sauna=b.sauna||room?.sauna||'F'; const roomName=b['dressing-room'];
  if(p.endsWith('give-up')){const found=[...state.slots.values()].find(x=>x.household===b.household&&x.room===roomName&&x.weekday===b.weekday&&x.start===b.start);if(!found)return json(res,404,{error:`Apartment ${b.household} does not hold ${b.weekday} at ${b.start} in ${roomName}.`});state.slots.delete(found.id);state.billing.delete(found.id);emit('@item-01-008','loyly/standing-slot-released',found);return json(res,200,{message:`Apartment ${b.household} gave up ${b.weekday} ${b.start} in ${roomName}.`});}
  if(!room)return json(res,409,{error:'No sauna days are configured yet.',links:['/manage']}); if(!room.slots.includes(b.start))return json(res,409,{error:'There is no room for another standing slot.'}); if(!room.open.includes(b.weekday))return json(res,409,{error:`${roomName} is not open on ${b.weekday}.`,"open-days":room.open,availableDays:room.open});
  const held=[...state.slots.values()].find(x=>x.sauna===sauna&&x.room===roomName&&x.weekday===b.weekday&&x.start===b.start); if(held)return json(res,409,{error:`${b.weekday} at ${b.start} in ${roomName} is held by another household.`,"nearest-free-slot":room.slots.find(s=>![...state.slots.values()].some(x=>x.sauna===sauna&&x.room===roomName&&x.weekday===b.weekday&&x.start===s))||null,holder:held.household});
  const anyFree=room.slots.some(s=>![...state.slots.values()].some(x=>x.sauna===sauna&&x.room===roomName&&x.weekday===b.weekday&&x.start===s)); if(!anyFree)return json(res,409,{error:'There is no room for another standing slot.'});
  const slot={id:randomUUID(),household:b.household,room:roomName,sauna,weekday:b.weekday,start:b.start};state.slots.set(slot.id,slot);state.billing.set(slot.id,{"standing-slot-id":slot.id,household:b.household}); emit('@item-01-007','loyly/standing-slot-confirmed',slot);return json(res,201,{message:`Confirmed: apartment ${b.household} holds ${b.weekday} ${b.start} to ${endTime(b.start)} in ${roomName}, every week until it gives the slot up.`,"standing-slot":slot});}
 json(res,404,{error:'Not found'});
 }catch(e){json(res,400,{error:e.message})}};
const port=Number(process.argv[2]||process.env.PORT||8080);http.createServer(app).listen(port,'0.0.0.0');
