import test from 'node:test'; import assert from 'node:assert/strict';
test('candidate test runner reaches compose app', async()=>{const r=await fetch((process.env.BASE_URL||'http://app:8080')+'/health');assert.equal(r.status,200);assert.equal((await r.json()).status,'ok')});
