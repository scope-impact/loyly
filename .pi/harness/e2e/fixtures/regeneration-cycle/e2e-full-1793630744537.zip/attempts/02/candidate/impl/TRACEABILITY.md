# Traceability checklist (approved scope)

| approved item / Then step | implementation rule | candidate assertion |
|---|---|---|
| @item-01-001 / Tuesday has pukuhuone 8 slots | schedule is derived per room and weekday | Tuesday contains exact `dressing-room` pukuhuone 8 slots |
| @item-01-001 / Tuesday has no pukuhuone 9 slots | closed room days produce no entries | no Tuesday entry has `dressing-room` pukuhuone 9 |
| @item-01-002 / request refused closed day | validate room open weekdays before commit | exact 409 and exact `error` |
| @item-01-002 / refusal names open days | rejection includes actionable `open-days` | exact Thursday/Friday/Saturday array |
| @item-01-003 / confirmed 17:00–18:30 | committed slot uses 90-minute calculation | exact confirmation message and `start`/`end` |
| @item-01-003 / apartment 12 holds every Tuesday | authoritative slot records household and recurrence identity | exact `standing-slot.household`, weekday and room |
| @item-01-004 / held request refused | one-holder critical section rejects occupied key | exact held error and 409 |
| @item-01-004 / apartment 12 still holds | rejection never mutates slot map | holder and schedule remain apartment 12 |
| @item-01-005 / second slot confirmed | permit another free slot for same household | second 201 and exact slot identity |
| @item-01-005 / household holds two | all views project from slot map | schedule has exactly two apartment-12 entries |
| @item-01-006 / refused when full | no-free-slot validation leaves state unchanged | exact no-room 409 |
| @item-01-006 / exactly one remains | failed command does not commit | prior holder/count is asserted |
| @item-01-007 / posted list shows apartment 12 | schedule reads committed slot facts | exact household and room/start fields |
| @item-01-007 / heater heats 17:00–18:30 | heater projection derives from same slot | exact identity, weekday, start, end |
| @item-01-007 / billing names apartment 12 | billing projection derives from same slot | exact `standing-slot-id` and household |
| @item-01-008 / posted list removes slot | release atomically deletes authoritative fact | no matching schedule record |
| @item-01-008 / heater stops | heater is derived, not copied | no matching heater record |
| @item-01-008 / no further charge | billing is derived from live slot facts | no matching billing signal |
| @item-01-008 / views agree | all three reads use one committed state | all three absence assertions |
| @item-01-009 / exactly one confirmed | synchronous validate-and-commit critical section | overlapping Promise requests yield one 201 |
| @item-01-009 / other refused held | loser observes committed holder | one exact 409 held response |
| @item-01-009 / exactly one holder | unique slot key invariant | schedule has one holder |
| @item-01-009 / no derived view has two | projections enumerate authoritative slots | no duplicate identity in schedule |
| @item-01-010 / all 100 one winner | repeat same atomic operation 100 times | each pair has one 201 and one 409 |
| @item-01-010 / never both confirmed | unique key invariant | each iteration asserts success count 1 |
| @item-01-010 / never both refused | free initial state and atomic commit | each iteration asserts refusal count 1 |
| @item-01-011 / resident can name accepted request | closed-day response carries open days and slot input | follow-up request is constructed from refusal fields |
| @item-01-011 / unusable refusal fails budget | actionable response is externally testable | follow-up is not 400 and is accepted |

All dynamic path values are percent-encoded by tests and decoded by the server. Rejections are checked before mutation; the suite asserts preserved state where applicable. Runtime evidence assertions validate the exact configured record counts, required fields, and correlation fields without emitting candidate verdicts.
