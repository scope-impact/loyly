import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

function read(item) {
  const root=process.env.OTEL_FILE_EXPORT_DIR;
  if (!root) return null;
  const file=path.join(root,item,'runtime-signals.jsonl');
  if (!fs.existsSync(file)) return null;
  return fs.readFileSync(file,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);
}
async function waitFor(item) {
  for(let i=0;i<30;i++){const rows=read(item);if(rows)return rows;await new Promise(r=>setTimeout(r,100));}
  return null;
}
function assertEvidence(rows,eventType) {
  assert.ok(rows, 'runtime evidence missing');
  const events=rows.filter(x=>x.kind==='domain-event');
  const projections=rows.filter(x=>x.kind==='projection-snapshot');
  assert.equal(events.length,1); assert.equal(projections.length,3);
  const event=events[0];
  for(const k of ['operationId','eventId','aggregateId','schemaVersion','contentDigest']) assert.equal(typeof event[k],'string');
  assert.equal(event.eventType,eventType); assert.equal(event.complete,true);
  assert.deepEqual(projections.map(x=>x.projectionName).sort(),['billing-signals','heater-schedule','weekly-schedule']);
  for(const p of projections){assert.equal(p.complete,true);assert.equal(p.operationId,event.operationId);assert.equal(p.eventId,event.eventId);assert.equal(p.aggregateId,event.aggregateId);assert.ok(p.contentDigest);}
}
test('runtime evidence follows the declared correlated record contract', async()=>{
  if(!process.env.OTEL_FILE_EXPORT_DIR) return;
  assertEvidence(await waitFor('@item-01-007'),'loyly/standing-slot-confirmed');
  assertEvidence(await waitFor('@item-01-008'),'loyly/standing-slot-released');
});
