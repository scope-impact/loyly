#!/bin/sh
exec node server.js "${1:-${PORT:-8080}}"
