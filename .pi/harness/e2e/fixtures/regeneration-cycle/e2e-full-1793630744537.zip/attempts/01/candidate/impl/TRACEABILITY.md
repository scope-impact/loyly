# Traceability checklist
| item | implementation rule | candidate assertion |
|---|---|---|
|01-001|room-local weekday projection|schedule asserts room 8 Tuesday and room 9 absent|
|01-002|closed-day refusal includes open days|assert status, exact error, open-days and follow-up inputs|
|01-003|atomic confirmed slot with 90-minute end|assert confirmation message and slot fields|
|01-004|unique slot critical section|assert held rejection and holder preserved|
|01-005|multiple household slots while free|assert two committed slots|
|01-006|no-free-slot rejection|assert rejection and prior slot count|
|01-007|single state derives schedule/heater/billing|assert each view identity fields and evidence records|
|01-008|release atomically removes slot and views|assert all three views empty and release evidence|
|01-009|synchronous map commit serializes race|overlapping requests assert one success/one held|
|01-010|repeat race 100 times|assert one success, never two or zero each run|
|01-011|rejection supplies actionable alternative|construct accepted request from refusal open-days/slot data|
|Then steps|exact JSON wire fields and values|candidate tests assert each response field, not aliases|
